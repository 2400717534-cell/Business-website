SETUP (XAMPP)
1. Extract this folder into C:\xampp\htdocs\
2. Start Apache and MySQL in XAMPP Control Panel.
3. Open http://localhost/phpmyadmin, choose Import, select database.sql, then click Go.
4. Visit http://localhost/wisdom-cloud-media-starter/
Admin: http://localhost/wisdom-cloud-media-starter/admin/login.php
Demo email: admin@wisdomcloud.local
Demo password: password
Change the demo password before deploying online. This is a starter version; more admin features and deployment security should be added before launch.
