<?php
try{$pdo=new PDO('mysql:host=127.0.0.1;dbname=wisdom_cloud_media;charset=utf8mb4','root','',[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);}
catch(PDOException $e){exit('Database unavailable. Start MySQL in XAMPP and import database.sql using phpMyAdmin.');}
